package datadriven;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Annotations {
	@BeforeTest
	public void UseridGeneration()
	{	
	System.out.println("beforetest");
	}
	@BeforeMethod
	public void UserpasswordGeneration()
	{	
	System.out.println("beforemethod");
	}
	@Test
	@Parameters({"username"})
	public void OpeningBrowser(String username)
	{
	System.out.println("test1");
	System.out.println(username);

	
	}	
	
	@Test(dataProvider="getData")
	public void Flightbooking(String username,String password)
	{
		
	System.out.println("test2");
	System.out.println(username);
	System.out.println(password);
	

	}
	
	@DataProvider
	public Object[][] getData()
	{
		//3 stands for number of time to run,2 stands for number of parameters should send
		Object[][] data=new Object[3][2];
		data[0][0]="abcd";
		data[0][1]="xyz0";
		
		data[1][0]="abcde";
		data[1][1]="xyz1";
				
		data[2][0]="abcdef";
		data[2][1]="xyz2";
		return data;
		
	}
	
	
	
	@AfterMethod
	public void Clearcache ()
	{	
	System.out.println("aftermethod");
	}

	@AfterTest
	public void Deletecookies()
	{	
	System.out.println("aftertest");
	}
}
