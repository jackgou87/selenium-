package datadriven;

import org.testng.annotations.Test;

public class DependencyAnnotation {

	@Test(groups={"Priority1"},timeOut=45000,enabled=true)
	public void OpeningBrowser()
	{
	System.out.println("test1");
	}	
	
	@Test(dependsOnMethods={"OpeningBrowser"},alwaysRun=true)
	public void Flightbooking()
	
	{
		
	System.out.println("test2");
	}
	
	@Test(enabled=false)
	public void Newtest()
	{
	System.out.println("test3");	
	}	
	
}

