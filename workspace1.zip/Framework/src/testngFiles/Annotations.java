package testngFiles;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Annotations {
	@BeforeTest
	public void UseridGeneration()
	{	
	System.out.println("beforetest");
	}
	@BeforeMethod
	public void UserpasswordGeneration()
	{	
	System.out.println("beforemethod");
	}
	@Test
	public void OpeningBrowser()
	{
	System.out.println("test1");
	}	
	@Test
	public void Flightbooking()
	{
		
	System.out.println("test2");

	}
	@AfterMethod
	public void Clearcache ()
	{	
	System.out.println("aftermethod");
	}

	@AfterTest
	public void Deletecookies()
	{	
	System.out.println("aftertest");
	}
}
