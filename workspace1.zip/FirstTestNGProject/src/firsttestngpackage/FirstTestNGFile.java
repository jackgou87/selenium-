package firsttestngpackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class FirstTestNGFile {
	
  @Test
  public void f() {
	  WebDriver driver;
		driver = new FirefoxDriver();
		
		String baseURL = "http://demostore.x-cart.com/";
		driver.manage().window().maximize();
		driver.get(baseURL);
		
		// "#" - id and "." - class
		
		driver.findElement(By.cssSelector("#substring-default")).sendKeys("iphone");
  }
}
