import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class jdbcconection {

	public static void main(String[] args) throws SQLException {
		String host="localhost";
		String port="3306";
		Connection con=DriverManager.getConnection("jdbc:mysql://"+host+":"+port+"/Qadbt", "root", "Aa0871011");
		Statement s=con.createStatement();
		ResultSet rs=s.executeQuery("select * from Employeeinfo where id=2");	
		while(rs.next())
		{
		System.out.println(rs.getString("name"));
		}
	}

}
