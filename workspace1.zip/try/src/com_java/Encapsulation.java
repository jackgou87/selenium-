package com_java;


	public class Encapsulation{  
		private String name;  
		   
		public String getName(){  
		return name;  
		}  
		public void setName(String name){  
		this.name=name ; 
		}  
}
