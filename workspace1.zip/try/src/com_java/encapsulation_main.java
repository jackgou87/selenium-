package com_java;

public class encapsulation_main {
	public static void main(String[] args){
	Encapsulation student=new Encapsulation(); 
	student.setName("jack");
	System.out.println(student.getName());
	}
}
