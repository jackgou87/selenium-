package com_java;

public class wrapper {

	public static void main(String[] args) {
		
		//Converting Integer to int  
		Integer a=new Integer(3);    
		int i=a.intValue();//converting Integer to int  
		int j=a;//unboxing, now compiler will write a.intValue() internally    
		    
		System.out.println(a+" "+i+" "+j);    
		
		//Converting int into Integer  
		int b=20;  
		Integer x=Integer.valueOf(b);//converting int into Integer  
		Integer y=b;//autoboxing, now compiler will write Integer.valueOf(a) internally  
		  
		System.out.println(b+" "+x+" "+y);  
		
	}

}
