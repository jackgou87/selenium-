//testng reporter
package tutorial.selenium;
//import ������Ķ���
import java.util.Arrays;

import org.testng.annotations.*;
import org.testng.Assert;
import org.testng.Reporter;
//assert ���ܿ����ж��Դ���assert true,false,equal
public class TestNG_ReportersAndAsserts {

	@Test
	public void testStrings() {
		String actualString = "Test Reporters And Asserts";
		//true���log��actualString�������ֵ
		Reporter.log("The actual string is " + actualString, true);
		//"Test Reporters And Asserts"Ϊexpect value�����о��ǶԱ�actual value��expect value
		Assert.assertEquals(actualString, "Test Reporters And Asserts");
		//Reporter.log�Ĺ��ܾ��Ǵ���
		Reporter.log("Verifying the actual string with expected value", true);
		//print extra line
		Reporter.log("");
	}
	
	@Test
	public void testInt() {
		int actualInt = 10;
		//print,true��������print
		Reporter.log("The actual integer is " + actualInt, true);
		//actual value =actualInt=10,expect value=10
		Assert.assertEquals(actualInt, 10);
		//print
		Reporter.log("Verifying the actual integer with expected value", true);
		//print
		Reporter.log("");
	}
	
	@Test
	public void testArrays() {
		int[] actualArray = {1, 2, 3};
		int[] expectedArray = {1, 2, 3};
		Reporter.log("The actual array is " + Arrays.toString(actualArray) , true);
		Assert.assertEquals(actualArray, expectedArray);
		Reporter.log("Verifying the actual array with expected value", true);
		Reporter.log("");
	}

}
