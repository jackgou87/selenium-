package utilities;

public class Constants {
      public static final String URL = "http://www.expedia.com";
      public static final String File_Path = "//Users//tomara//Documents//workspace//SeleniumWD2Tutorial//src//utilities//";
      public static final String File_Name = "ExcelData.xlsx";
}