package advanced_action_multiwindow;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class mouse {

	public static void main(String[] args) {
		WebDriver driver=new FirefoxDriver();
		driver.get("http://www.amazon.com/");
		Actions abc=new Actions(driver);
		WebElement element=driver.findElement(By.xpath(".//*[@id='nav-link-yourAccount']/span[2]"));
		//move your mouse to one place and hang there
		//build and perform is like a standard 
		abc.moveToElement(element).build().perform();
		// write in capital letters
		WebElement xyz=driver.findElement(By.xpath(".//*[@id='twotabsearchtextbox']"));
		abc.keyDown(Keys.SHIFT).moveToElement(xyz).click().sendKeys("suitcase").build().perform();
		//right click
		abc.contextClick(xyz).build().perform();

	}

}
