package advanced_action_multiwindow;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class multiwindow {

	public static void main(String[] args) {
		WebDriver driver= new FirefoxDriver();
		driver.get("https://accounts.google.com/signup");
		driver.findElement(By.xpath(".//*[@id='wrapper']/div[2]/div/div[1]/p/a")).click();
		System.out.println(driver.getTitle());
		//multi window set[]
		Set<String>ids=driver.getWindowHandles();
		Iterator<String> it=ids.iterator();
		String parentid=it.next();
		String childid=it.next();
		//swith to child ID
		driver.switchTo().window(childid);
		System.out.println(driver.getTitle());
		//swith back to parent ID
		driver.switchTo().window(parentid);
		System.out.println(driver.getTitle());



}

}
