package advanced_action_multiwindow;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class frame {

	public static void main(String[] args) {
		WebDriver driver=new FirefoxDriver();
		driver.get("https://netbanking.hdfcbank.com/netbanking/");
		//detect frame by using getpagesource,two kinds iframe id and frameset
		System.out.print(driver.getPageSource());
		//Begins with 0
		driver.switchTo().frame("login_page");
		
		driver.findElement(By.cssSelector("input[class='input_password']")).sendKeys("10000");
		driver.findElement(By.xpath("html/body/form/table[2]/tbody/tr/td[2]/table/tbody/tr[1]/td[1]/table/tbody/tr[3]/td[2]/table/tbody/tr[2]/td[2]/span/input")).sendKeys("10000");
	}

}
