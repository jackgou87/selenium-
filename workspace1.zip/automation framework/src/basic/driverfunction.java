package basic;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class driverfunction {

	public static void main(String[]args){
		WebDriver driver=new FirefoxDriver();
		driver.get("http://google.com");
		System.out.print(driver.getTitle());
		//System.out.print(driver.getPageSource());
		System.out.print(driver.getCurrentUrl());
		driver.manage().window().maximize();
		driver.close();
		
	}
}
