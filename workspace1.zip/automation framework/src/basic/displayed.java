package basic;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class displayed {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new FirefoxDriver();
		//Is displayed is used when particular object is in code base but it is in visible mode or not
		driver.get("http://www.makemytrip.com/flights");
		System.out.println(" Before clikcing on Multi city Radio button");
		System.out.println(driver.findElement(By.xpath(".//*[@id='return_date_sec']/span[3]")).isDisplayed());
		System.out.println(driver.findElements(By.xpath(".//*[@id='return_date_sec']/span[3]")).size());
		System.out.println(" after clikcing on Multi city Radio button");
		driver.findElement(By.xpath(".//*[@id='multi_city_button']/span")).click();
		System.out.println(driver.findElement(By.xpath(".//*[@id='return_date_sec']/span[3]")).isEnabled());
		System.out.println(driver.findElements(By.xpath(".//*[@id='return_date_sec']/span[3]")).size());
		//have to have InterruptedException then can work
		Thread.sleep(1000L);
		//do not have to have text tag	
		System.out.println(driver.findElement(By.xpath(".//*[@id='mboxClick-raw_DF_Row1A_Mbox']/h3")).getText());
		int i =0;
		while(i<5);
		{
			driver.findElement(By.xpath(".//*[@id='child_count_multi']/a[2]")).click();
			i++;
		}
	}

}
