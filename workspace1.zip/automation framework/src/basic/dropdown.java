package basic;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class dropdown {
//handle dynamic dropdown
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\selenium\\Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://spicejet.com");
		driver.findElement(By.xpath("//*[@id='ctl00_mainContent_ddl_originStation1_CTXT']")).click();
		driver.findElement(By.xpath("//a[@text='Goa (GOI)']")).click();
//handle static dropdown		
		Select dropdown=new Select(driver.findElement(By.xpath("//select[@id='ctl00_mainContent_ddl_Adult']")));
		dropdown.selectByIndex(1);
		dropdown.selectByVisibleText("9 Adults");
		dropdown.selectByValue("8");
//handle checkbox
		driver.findElement(By.xpath(".//input[@type='checkbox']")).click();
		//isSelected()
		System.out.println(driver.findElement(By.xpath(".//input[@type='checkbox']")).isSelected());
	}

}
