package pagefactorytests;



import org.testng.annotations.Test;

import pageclasses.homePageFactory;

import org.testng.annotations.BeforeClass;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;

public class SignoffPageFactoryTestCase {
	private WebDriver driver;
	private String baseUrl;
	//declare
	homePageFactory homePage;

	@BeforeClass
	public void beforeClass() {
		driver = new FirefoxDriver();
		baseUrl = "http://107.170.213.234/catalog/";
		//initialize
		homePage = new homePageFactory(driver);

		// Maximize the browser's window
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get(baseUrl);
	}

	@Test
	public void test01() {
		homePage.clickMyaccountTab();
		homePage.setEMailAddress("ecalix@test.com");
		homePage.setPassword("test123");
		homePage.clickSigninbutton();
		homePage.clickSignoffbutton();
	}

	@AfterClass
	public void afterClass() {
	}
}
