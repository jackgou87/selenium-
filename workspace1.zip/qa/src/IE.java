

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class IE{

	public static void main(String[] args) {
		// http://chromedriver.storage.googleapis.com/index.html
		String baseURL = "http://www.google.com";
		System.setProperty("webdriver.ie.driver", "C:\\selenium\\Drivers\\IEDriverServer.exe");
		WebDriver driver;
		driver = new InternetExplorerDriver();
		
		driver.get(baseURL);

	}

}
