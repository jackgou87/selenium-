import java.util.concurrent.TimeUnit;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;





@SuppressWarnings("deprecation")
public class MynewtestcaseTESTNG {
	public String URL="http://107.170.213.234/catalog";
	public WebDriver driver;
	
	@BeforeTest
	public void setup(){
		driver =new FirefoxDriver();
		System.out.println("Opening FireFox Browser");
		
		driver.get(URL);
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	}
	
	@AfterTest
	public void setup1(){
	driver.quit();
	System.out.println("Browser closed");
	}
	
	@Test
 	
	public void Login01(){
		driver =new FirefoxDriver();
		System.out.println("Opening FireFox Browser");
		
		driver.get(URL);
		System.out.println("URL is opened");
		driver.findElement(By.xpath("html/body/div[1]/div[3]/div/div[1]/a[1]/u")).click();
		System.out.println("Clicking the log yourself link");
 		
		
		driver.findElement(By.name("email_address")).sendKeys("ecalix@test.com");
		driver.findElement(By.name("password")).sendKeys("test123");
		System.out.println("Enter ID/Password");
		
		driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/div/form/p[2]/span/button")).click();
		System.out.println("sign-in click");
		
		
		String ExpectedTest="Welcome to iBusiness";
		String ActualTest=driver.findElement(By.xpath("/html/body/div[1]/div[3]/h1")).getText();
		System.out.println(ExpectedTest+" Compare "+ActualTest);
		Assert.assertEquals(ExpectedTest, ActualTest);

		
		
		
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[2]/span[4]/a/span")).click();
		driver.quit();
		System.out.println("Browser closed");
		
		
		
	}
	
@Test
 	
	public void Login02(){
		driver =new FirefoxDriver();
		System.out.println("Opening FireFox Browser");
		driver.get(URL);
		System.out.println("URL is opened");
		driver.findElement(By.xpath(".//*[@id='tdb3']/span[2]")).click();
		System.out.println("Clicking the account");
		
		driver.findElement(By.name("email_address")).sendKeys("ecalix@test.com");
		driver.findElement(By.name("password")).sendKeys("test1234");
		driver.findElement(By.xpath(".//*[@id='tdb5']")).click();
		String ExpectedTest=" Error: No match for E-Mail Address and/or Password.";
		String ActualTest=driver.findElement(By.xpath(".//*[@id='bodyContent']/table/tbody/tr/td")).getText();
		System.out.println(ExpectedTest+" Compare "+ActualTest);
		Assert.assertEquals(ExpectedTest, ActualTest);
	}
}
	
	
	
	
