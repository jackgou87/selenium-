package pageclasses;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class homePageFactory {
	WebDriver driver;
	
	@FindBy(xpath=".//*[@id='tdb3']/span[2]")
	WebElement Myaccount;
	
	@FindBy(xpath=".//*[@id='bodyContent']/div[2]/div/form/table/tbody/tr[1]/td[2]/input")
	WebElement EMailAddress;
	
	@FindBy(xpath=".//*[@id='bodyContent']/div[2]/div/form/table/tbody/tr[2]/td[2]/input")
	WebElement Password;
	
	@FindBy(xpath=".//*[@id='tdb5']")
	WebElement Signinbutton;
	
	@FindBy(xpath=".//*[@id='tdb4']/span")
	WebElement Signoffbutton;
	//��������element
	public homePageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	//����Ϊ��Ҫʵ�ֵ��ĸ�����
	public void clickMyaccountTab() {
		Myaccount.click();
		
	}
	
	public void setEMailAddress(String eMailAddress) {
		EMailAddress.sendKeys(eMailAddress);
	}
	
	public void setPassword(String password) {
		Password.sendKeys(password);
	}
	
	public void clickSigninbutton() {
		Signinbutton.click();
	}
	public void clickSignoffbutton() {
		Signoffbutton.click();
	}
}
